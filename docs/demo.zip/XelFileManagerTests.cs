﻿using NotificationFunction.Models.DataLake;
using NotificationFunction.Models.Manager;
using NotificationFunction.Resources;
using NotificationFunction.Service.Manager;

namespace NotificationFunction.Tests.Service.Manager
{
    /// <summary>
    /// XelFileManagerの単体テストクラス
    /// </summary>
    [TestClass]
    public class XelFileManagerTests
    {
        private string _tempDir = null!;
        private XelFileManager _target = null!;

        [TestInitialize]
        public void Setup()
        {
            _tempDir = Path.Combine(Path.GetTempPath(), "XelFileTests_" + Guid.NewGuid());
            Environment.SetEnvironmentVariable(EnvironmentValue.XEL_FILE_PATH, _tempDir);
            _target = new XelFileManager();
        }

        [TestCleanup]
        public void Cleanup()
        {
            if (Directory.Exists(_tempDir))
            {
                Directory.Delete(_tempDir, true);
            }
        }

        private static LogFileInfoModel CreateXelModel() => new()
        {
            DirectoryPath = "server01/db01/SqlDbAuditing/2026-11-13",
            FileName = "audit.xel"
        };

        /// <summary>
        /// 出力ディレクトリが未存在の場合、新規作成してファイル出力されることを確認
        /// </summary>
        [TestMethod]
        public async Task OutputFileAsync_ディレクトリ未存在_新規作成してファイル出力()
        {
            // Arrange
            var model = CreateXelModel();
            var xel = new LastXelFile { FileName = "audit.xel" };

            // Act
            await _target.OutputFileAsync(model, xel);

            // Assert
            Assert.IsTrue(Directory.Exists(_tempDir));
            Assert.IsTrue(await _target.IsExists(model));
        }

        /// <summary>
        /// 出力ディレクトリが既存の場合、ファイルが上書き出力されることを確認
        /// </summary>
        [TestMethod]
        public async Task OutputFileAsync_ディレクトリ既存_ファイル上書き出力()
        {
            // Arrange
            Directory.CreateDirectory(_tempDir);
            var model = CreateXelModel();
            await _target.OutputFileAsync(model, new LastXelFile { FileName = "old.xel" });

            // Act
            await _target.OutputFileAsync(model, new LastXelFile { FileName = "new.xel" });

            // Assert
            var loaded = await _target.GetFileAsync(model);
            Assert.AreEqual("new.xel", loaded.FileName);
        }

        /// <summary>
        /// 管理ファイルが存在する場合、内容を正常に取得できることを確認
        /// </summary>
        [TestMethod]
        public async Task GetFileAsync_管理ファイル存在_内容取得()
        {
            // Arrange
            var model = CreateXelModel();
            await _target.OutputFileAsync(model, new LastXelFile { FileName = "audit.xel" });

            // Act
            var result = await _target.GetFileAsync(model);

            // Assert
            Assert.AreEqual("audit.xel", result.FileName);
        }

        /// <summary>
        /// 削除対象ファイルが0件の場合、例外なく正常終了することを確認
        /// </summary>
        [TestMethod]
        public async Task DeleteFileAsync_対象ファイル0件_正常終了()
        {
            // Arrange
            Directory.CreateDirectory(_tempDir);
            var model = CreateXelModel();

            // Act & Assert
            await _target.DeleteFileAsync(model);
            Assert.IsFalse(await _target.IsExists(model));
        }

        /// <summary>
        /// 削除対象ファイルが1件存在する場合、正常に削除されることを確認
        /// </summary>
        [TestMethod]
        public async Task DeleteFileAsync_対象ファイル1件_削除実行()
        {
            // Arrange
            var model = CreateXelModel();
            await _target.OutputFileAsync(model, new LastXelFile { FileName = "audit.xel" });

            // Act
            await _target.DeleteFileAsync(model);

            // Assert
            Assert.IsFalse(await _target.IsExists(model));
        }

        /// <summary>
        /// 管理ファイルが存在する場合、IsExistsがTrueを返却することを確認
        /// </summary>
        [TestMethod]
        public async Task IsExists_管理ファイルあり_True返却()
        {
            // Arrange
            var model = CreateXelModel();
            await _target.OutputFileAsync(model, new LastXelFile { FileName = "audit.xel" });

            // Act
            var result = await _target.IsExists(model);

            // Assert
            Assert.IsTrue(result);
        }

        /// <summary>
        /// 管理ファイルが存在しない場合、IsExistsがFalseを返却することを確認
        /// </summary>
        [TestMethod]
        public async Task IsExists_管理ファイルなし_False返却()
        {
            // Arrange
            Directory.CreateDirectory(_tempDir);
            var model = CreateXelModel();

            // Act
            var result = await _target.IsExists(model);

            // Assert
            Assert.IsFalse(result);
        }
    }
}
