﻿using Microsoft.Graph;
using Moq;
using NotificationFunction.Models.CosmosDB;
using NotificationFunction.Resources;
using NotificationFunction.Service.CosmosDB.Interfaces;
using NotificationFunction.Service.Logger.Interfaces;
using NotificationFunction.Service.Manager;
using System.Net;
using System.Reflection;
using System.Text;

namespace NotificationFunction.Tests.Service.Manager
{
    /// <summary>
    /// UserAccountManagerの単体テストクラス
    /// </summary>
    [TestClass]
    public class UserAccountManagerTests
    {
        private Mock<IAPPLogger> _mockAppLogger = null!;
        private Mock<ICosmosDBService> _mockCosmosService = null!;
        private UserAccountManager _target = null!;

        [TestInitialize]
        public void Setup()
        {
            _mockAppLogger = new Mock<IAPPLogger>();
            _mockCosmosService = new Mock<ICosmosDBService>();
            _target = new UserAccountManager(_mockAppLogger.Object);
        }

        private void SetPrivateField(string fieldName, object? value)
        {
            var field = typeof(UserAccountManager).GetField(fieldName, BindingFlags.Instance | BindingFlags.NonPublic);
            field?.SetValue(_target, value);
        }

        private T? GetPrivateField<T>(string fieldName)
        {
            var field = typeof(UserAccountManager).GetField(fieldName, BindingFlags.Instance | BindingFlags.NonPublic);
            return (T?)field?.GetValue(_target);
        }

        private class MockHttpMessageHandler(Func<HttpRequestMessage, HttpResponseMessage> handler) : HttpMessageHandler
        {
            protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
                => Task.FromResult(handler(request));
        }

        /// <summary>
        /// DBデータが取得できた場合、リストが正常に初期化されることを確認
        /// </summary>
        [TestMethod]
        public async Task GetDBData_データあり_初期化完了()
        {
            // Arrange
            var dbList = new List<UserIdManagementModel>
            {
                new() { ObjectId = "oid-1", Upn = "user1@example.com" }
            };
            _mockCosmosService.Setup(m => m.GetAllItemList<UserIdManagementModel>()).ReturnsAsync(dbList);

            // Act
            await _target.GetDBData(_mockCosmosService.Object);

            // Assert
            var data = GetPrivateField<List<UserIdManagementModel>>("Data");
            Assert.IsNotNull(data);
            Assert.AreEqual(1, data.Count);
        }

        /// <summary>
        /// DBデータが0件の場合、空リストで初期化されることを確認
        /// </summary>
        [TestMethod]
        public async Task GetDBData_データ0件_空リスト初期化()
        {
            // Arrange
            _mockCosmosService.Setup(m => m.GetAllItemList<UserIdManagementModel>()).ReturnsAsync([]);

            // Act
            await _target.GetDBData(_mockCosmosService.Object);

            // Assert
            var data = GetPrivateField<List<UserIdManagementModel>>("Data");
            Assert.IsNotNull(data);
            Assert.AreEqual(0, data.Count);
        }

        /// <summary>
        /// DBにデータが存在し履歴未登録の場合、DBのUPNが返却され履歴に追加されることを確認
        /// </summary>
        [TestMethod]
        public void GetUPN_DBにデータあり_履歴未登録_DBのUPN返却と履歴追加()
        {
            // Arrange
            SetPrivateField("Data", new List<UserIdManagementModel>
            {
                new() { ObjectId = "oid-1", Upn = "dbuser@example.com" }
            });

            // Act
            var upn = _target.GetUPN("oid-1");

            // Assert
            Assert.AreEqual("dbuser@example.com", upn);
            var history = GetPrivateField<List<string>>("OldHistory")!;
            Assert.AreEqual(1, history.Count);
            Assert.AreEqual("oid-1", history[0]);
        }

        /// <summary>
        /// DBにデータが存在し既に履歴登録済みの場合、履歴に重複追加されないことを確認
        /// </summary>
        [TestMethod]
        public void GetUPN_DBにデータあり_履歴登録済み_重複追加なし()
        {
            // Arrange
            SetPrivateField("Data", new List<UserIdManagementModel>
            {
                new() { ObjectId = "oid-1", Upn = "dbuser@example.com" }
            });

            // Act
            _target.GetUPN("oid-1");
            var upn = _target.GetUPN("oid-1");

            // Assert
            Assert.AreEqual("dbuser@example.com", upn);
            var history = GetPrivateField<List<string>>("OldHistory")!;
            Assert.AreEqual(1, history.Count);
        }

        /// <summary>
        /// DB未登録のOIDでGraphAPIからユーザーUPNを取得できた場合、リストに新規追加されることを確認
        /// </summary>
        [TestMethod]
        public void GetUPN_DB未登録_Graphユーザー取得成功_新規リスト追加()
        {
            // Arrange
            SetPrivateField("Data", new List<UserIdManagementModel>());
            var handler = new MockHttpMessageHandler(_ => new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("{\"userPrincipalName\":\"graphuser@example.com\"}", Encoding.UTF8, "application/json")
            });
            SetPrivateField("_graphClient", new GraphServiceClient(new HttpClient(handler)));

            // Act
            var upn = _target.GetUPN("oid-graph-1");

            // Assert
            Assert.AreEqual("graphuser@example.com", upn);
            var data = GetPrivateField<List<UserIdManagementModel>>("Data")!;
            Assert.AreEqual(1, data.Count);
        }

        /// <summary>
        /// ユーザー取得がODataErrorとなりサービスプリンシパルからdisplayNameを取得できた場合、その値が返却されることを確認
        /// </summary>
        [TestMethod]
        public void GetUPN_DB未登録_Graphサービスプリンシパル取得成功()
        {
            // Arrange
            SetPrivateField("Data", new List<UserIdManagementModel>());
            var handler = new MockHttpMessageHandler(req =>
            {
                if (req.RequestUri!.AbsolutePath.Contains("/users/"))
                {
                    return new HttpResponseMessage(HttpStatusCode.NotFound)
                    {
                        Content = new StringContent("{\"error\":{\"code\":\"Request_ResourceNotFound\",\"message\":\"Not found\"}}", Encoding.UTF8, "application/json")
                    };
                }
                return new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent("{\"displayName\":\"MyServicePrincipal\"}", Encoding.UTF8, "application/json")
                };
            });
            SetPrivateField("_graphClient", new GraphServiceClient(new HttpClient(handler)));

            // Act
            var upn = _target.GetUPN("oid-sp-1");

            // Assert
            Assert.AreEqual("MyServicePrincipal", upn);
        }

        /// <summary>
        /// GraphAPIからUPNキーが取得できない場合、ハイフン("-")が返却されることを確認
        /// </summary>
        [TestMethod]
        public void GetUPN_DB未登録_Graphユーザーキーなし_ハイフン返却()
        {
            // Arrange
            SetPrivateField("Data", new List<UserIdManagementModel>());
            var handler = new MockHttpMessageHandler(_ => new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("{}", Encoding.UTF8, "application/json")
            });
            SetPrivateField("_graphClient", new GraphServiceClient(new HttpClient(handler)));

            // Act
            var upn = _target.GetUPN("oid-empty");

            // Assert
            Assert.AreEqual("-", upn);
            Assert.AreEqual(0, GetPrivateField<List<UserIdManagementModel>>("Data")!.Count);
        }

        /// <summary>
        /// GraphAPI通信時に一般例外が発生した場合、エラーログ出力後にハイフン("-")が返却されることを確認
        /// </summary>
        [TestMethod]
        public void GetUPN_GraphAPI通信例外_ログ出力とハイフン返却()
        {
            // Arrange
            SetPrivateField("Data", new List<UserIdManagementModel>());
            var handler = new MockHttpMessageHandler(_ => throw new HttpRequestException("通信エラー"));
            SetPrivateField("_graphClient", new GraphServiceClient(new HttpClient(handler)));

            // Act
            var upn = _target.GetUPN("oid-err");

            // Assert
            Assert.AreEqual("-", upn);
            _mockAppLogger.Verify(l => l.WriteLog(It.Is<string>(s => s.Contains("oid-err")), LogLevel.ERROR, It.IsAny<Exception?>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// 証明書が見つからない場合、例外がキャッチされハイフン("-")が返却されることを確認
        /// </summary>
        [TestMethod]
        public void GetUPN_GraphClient未初期化_証明書未検出例外()
        {
            // Arrange
            Environment.SetEnvironmentVariable(EnvironmentValue.CERT_THUMBPRINT, "0000000000000000000000000000000000000000");
            SetPrivateField("Data", new List<UserIdManagementModel>());

            // Act
            var upn = _target.GetUPN("oid-cert-err");

            // Assert
            Assert.AreEqual("-", upn);
            _mockAppLogger.Verify(l => l.WriteLog(It.IsAny<string>(), LogLevel.ERROR, It.IsAny<Exception?>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// 追加・更新対象がともに0件の場合、DB登録処理がスキップされることを確認
        /// </summary>
        [TestMethod]
        public async Task RegisterDataInDB_追加更新ともに0件_登録スキップ()
        {
            // Arrange
            var list = new List<UserIdManagementModel> { new() { ObjectId = "oid-1", Upn = "u1@test.com" } };
            SetPrivateField("OriginalData", list);
            SetPrivateField("Data", new List<UserIdManagementModel>(list));
            SetPrivateField("OldHistory", new List<string>());

            // Act
            await _target.RegisterDataInDB(_mockCosmosService.Object);

            // Assert
            _mockCosmosService.Verify(m => m.PostItem(It.IsAny<UserIdManagementModel>(), It.IsAny<bool>()), Times.Never);
        }

        /// <summary>
        /// 新規追加データがある場合、ハイフン("-")を除外して新規登録されることを確認
        /// </summary>
        [TestMethod]
        public async Task RegisterDataInDB_新規追加データあり_ハイフン除外で登録()
        {
            // Arrange
            var orig = new List<UserIdManagementModel>();
            var validItem = new UserIdManagementModel { ObjectId = "oid-new", Upn = "new@test.com" };
            var unknownItem = new UserIdManagementModel { ObjectId = "oid-unk", Upn = "-" };
            SetPrivateField("OriginalData", orig);
            SetPrivateField("Data", new List<UserIdManagementModel> { validItem, unknownItem });

            // Act
            await _target.RegisterDataInDB(_mockCosmosService.Object);

            // Assert
            _mockCosmosService.Verify(m => m.PostItem(validItem, false), Times.Once);
            _mockCosmosService.Verify(m => m.PostItem(unknownItem, false), Times.Never);
        }

        /// <summary>
        /// 新規追加処理で例外が発生しても破棄され、後続処理が継続されることを確認
        /// </summary>
        [TestMethod]
        public async Task RegisterDataInDB_新規追加例外_例外破棄で処理継続()
        {
            // Arrange
            var item1 = new UserIdManagementModel { ObjectId = "oid-1", Upn = "u1@test.com" };
            var item2 = new UserIdManagementModel { ObjectId = "oid-2", Upn = "u2@test.com" };
            SetPrivateField("OriginalData", new List<UserIdManagementModel>());
            SetPrivateField("Data", new List<UserIdManagementModel> { item1, item2 });

            _mockCosmosService.Setup(m => m.PostItem(item1, false)).ThrowsAsync(new Exception("登録失敗"));

            // Act
            await _target.RegisterDataInDB(_mockCosmosService.Object);

            // Assert
            _mockCosmosService.Verify(m => m.PostItem(item2, false), Times.Once);
        }

        /// <summary>
        /// 既存データの問い合わせ履歴がある場合、上書き更新(overwrite=true)が実行されることを確認
        /// </summary>
        [TestMethod]
        public async Task RegisterDataInDB_更新対象あり_上書き登録実行()
        {
            // Arrange
            var existingItem = new UserIdManagementModel { ObjectId = "oid-1", Upn = "u1@test.com" };
            SetPrivateField("OriginalData", new List<UserIdManagementModel> { existingItem });
            SetPrivateField("Data", new List<UserIdManagementModel> { existingItem });
            SetPrivateField("OldHistory", new List<string> { "oid-1" });

            // Act
            await _target.RegisterDataInDB(_mockCosmosService.Object);

            // Assert
            _mockCosmosService.Verify(m => m.PostItem(existingItem, true), Times.Once);
        }

        /// <summary>
        /// 更新処理で例外が発生しても破棄され、後続処理が継続されることを確認
        /// </summary>
        [TestMethod]
        public async Task RegisterDataInDB_更新登録例外_例外破棄で処理継続()
        {
            // Arrange
            var item1 = new UserIdManagementModel { ObjectId = "oid-1", Upn = "u1@test.com" };
            var item2 = new UserIdManagementModel { ObjectId = "oid-2", Upn = "u2@test.com" };
            SetPrivateField("OriginalData", new List<UserIdManagementModel> { item1, item2 });
            SetPrivateField("Data", new List<UserIdManagementModel> { item1, item2 });
            SetPrivateField("OldHistory", new List<string> { "oid-1", "oid-2" });

            _mockCosmosService.Setup(m => m.PostItem(item1, true)).ThrowsAsync(new Exception("更新失敗"));

            // Act
            await _target.RegisterDataInDB(_mockCosmosService.Object);

            // Assert
            _mockCosmosService.Verify(m => m.PostItem(item2, true), Times.Once);
        }
    }
}
