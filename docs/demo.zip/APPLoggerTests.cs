﻿using AP01.API;
using Moq;
using NotificationFunction.Service.Logger;
using System.Reflection;

namespace NotificationFunction.Tests.Service.Logger
{
    /// <summary>
    /// APPLoggerの単体テストクラス
    /// </summary>
    [TestClass]
    public class APPLoggerTests
    {
        private Mock<IModule> _mockLoggerModule = null!;
        private APPLogger _target = null!;

        [TestInitialize]
        public void Setup()
        {
            _mockLoggerModule = new Mock<IModule>();
            SetPrivateStaticLogger(_mockLoggerModule.Object);
            _target = new APPLogger();
        }

        [TestCleanup]
        public void Cleanup()
        {
            SetPrivateStaticLogger(null);
        }

        private static void SetPrivateStaticLogger(IModule? module)
        {
            var field = typeof(APPLogger).GetField("_logger", BindingFlags.Static | BindingFlags.NonPublic);
            field?.SetValue(null, module);
        }

        /// <summary>
        /// 例外なしでWriteLogを呼び出した場合、半角波括弧が全角に置換されてログ出力されることを確認
        /// </summary>
        [TestMethod]
        public void WriteLog_例外なし_波括弧全角置換でログ出力()
        {
            // Arrange
            string message = "処理開始{param1}";

            // Act
            _target.WriteLog(message, "INFO", null);

            // Assert
            _mockLoggerModule.Verify(m => m.DoSetString(
                MethodEnum.POST,
                It.Is<string>(l => l.Contains("INFO")),
                It.Is<string>(c => c.Contains("処理開始｛param1｝"))), Times.Once);
        }

        /// <summary>
        /// 例外ありでWriteLogを呼び出した場合、例外情報が付加されてログ出力されることを確認
        /// </summary>
        [TestMethod]
        public void WriteLog_例外あり_例外情報付加でログ出力()
        {
            // Arrange
            var ex = new InvalidOperationException("無効な操作です");

            // Act
            _target.WriteLog("エラー発生", "ERROR", ex);

            // Assert
            _mockLoggerModule.Verify(m => m.DoSetString(
                MethodEnum.POST,
                It.Is<string>(l => l.Contains("ERROR")),
                It.Is<string>(c => c.Contains("エラー発生") && c.Contains("無効な操作です"))), Times.Once);
        }

        /// <summary>
        /// ログ出力処理中に例外が発生した場合、例外が外部にスローされず破棄されることを確認
        /// </summary>
        [TestMethod]
        public void WriteLog_ログ出力例外発生_例外破棄()
        {
            // Arrange
            _mockLoggerModule.Setup(m => m.DoSetString(It.IsAny<MethodEnum>(), It.IsAny<string>(), It.IsAny<string>()))
                .Throws(new Exception("ログ出力失敗"));

            // Act & Assert (例外がスローされないこと)
            _target.WriteLog("テストログ", "ERROR", null);
        }
    }
}
