﻿using Moq;
using NotificationFunction.Logic.Detect;
using NotificationFunction.Models.CosmosDB;
using NotificationFunction.Models.DataLake;
using NotificationFunction.Models.Error;
using NotificationFunction.Resources;
using NotificationFunction.Service.CosmosDB.Interfaces;
using NotificationFunction.Service.DataLake.Interfaces;
using NotificationFunction.Service.Error.Interfaces;
using NotificationFunction.Service.Logger.Interfaces;
using NotificationFunction.Service.Manager.Interfaces;

namespace NotificationFunction.Tests.Logic.Detect
{
    /// <summary>
    /// DetectLogicの単体テストクラス
    /// </summary>
    [TestClass]
    public class DetectLogicTests
    {
        private Mock<IDataLakeService> _mockDataLakeService = null!;
        private Mock<ICosmosDBService> _mockCosmosDBService = null!;
        private Mock<IErrorFileManager> _mockErrorFileManager = null!;
        private Mock<IAlertService> _mockAlertService = null!;
        private Mock<IAPPLogger> _mockAppLogger = null!;
        private Mock<ITimeManager> _mockTimeManager = null!;
        private Mock<IUserAccountManager> _mockUserAccountManager = null!;
        private DetectLogic _target = null!;

        [TestInitialize]
        public void Setup()
        {
            Environment.SetEnvironmentVariable(EnvironmentValue.ELAPSED_TIME_THRESHOLD, "25");
            Environment.SetEnvironmentVariable(EnvironmentValue.DATALAKE_COSMOSDBACCOUNT_CONTAINER_NAMES, "cosmosdb-container");

            _mockDataLakeService = new Mock<IDataLakeService>();
            _mockCosmosDBService = new Mock<ICosmosDBService>();
            _mockErrorFileManager = new Mock<IErrorFileManager>();
            _mockAlertService = new Mock<IAlertService>();
            _mockAppLogger = new Mock<IAPPLogger>();
            _mockTimeManager = new Mock<ITimeManager>();
            _mockUserAccountManager = new Mock<IUserAccountManager>();

            _mockTimeManager.Setup(m => m.GetElapsedTime()).Returns(TimeSpan.FromMinutes(1));
            _mockErrorFileManager.Setup(m => m.IsExists(It.IsAny<LogFileInfoModel>())).ReturnsAsync(false);

            _target = new DetectLogic(
                _mockDataLakeService.Object,
                _mockCosmosDBService.Object,
                _mockErrorFileManager.Object,
                _mockAlertService.Object,
                _mockAppLogger.Object,
                _mockTimeManager.Object,
                _mockUserAccountManager.Object);
        }

        private static LogFileInfoModel CreateFileInfo(string container = "storage-container") => new()
        {
            ContainerName = container,
            DirectoryPath = "dir/",
            FileName = "test.json"
        };

        /// <summary>
        /// 開始時に実行時間閾値を超過している場合、即座に処理中断されることを確認
        /// </summary>
        [TestMethod]
        public async Task RunDetectLogic_開始時閾値超過_処理中断()
        {
            // Arrange
            _mockTimeManager.Setup(m => m.GetElapsedTime()).Returns(TimeSpan.FromMinutes(30));

            // Act
            await _target.RunDetectLogic(CreateFileInfo(), [], [], []);

            // Assert
            _mockErrorFileManager.Verify(m => m.IsExists(It.IsAny<LogFileInfoModel>()), Times.Never);
        }

        /// <summary>
        /// 前回失敗ファイル確認時に例外が発生した場合、エラーファイルとトレースログが出力されることを確認
        /// </summary>
        [TestMethod]
        public async Task RunDetectLogic_前回失敗ファイル確認例外_エラー出力()
        {
            // Arrange
            var fileInfo = CreateFileInfo();
            _mockErrorFileManager.Setup(m => m.IsExists(fileInfo)).ThrowsAsync(new Exception("確認失敗"));

            // Act
            await _target.RunDetectLogic(fileInfo, [], [], []);

            // Assert
            _mockErrorFileManager.Verify(m => m.OutputErrorFile(fileInfo, 0, false), Times.Once);
            _mockAppLogger.Verify(m => m.WriteLog(Messages.T_001, LogLevel.TRACE, It.IsAny<Exception?>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// ログ内容取得時に例外が発生した場合、エラーファイルとトレースログが出力されることを確認
        /// </summary>
        [TestMethod]
        public async Task RunDetectLogic_ログ内容取得例外_エラー出力()
        {
            // Arrange
            var fileInfo = CreateFileInfo();
            _mockDataLakeService.Setup(m => m.GetLogContents(fileInfo)).Throws(new Exception("取得失敗"));

            // Act
            await _target.RunDetectLogic(fileInfo, [], [], []);

            // Assert
            _mockErrorFileManager.Verify(m => m.OutputErrorFile(fileInfo, 0, false), Times.Once);
            _mockAppLogger.Verify(m => m.WriteLog(Messages.T_002, LogLevel.TRACE, It.IsAny<Exception?>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// ログ内容が0件の場合、判定・通知をスキップしログ削除のみ実行されることを確認
        /// </summary>
        [TestMethod]
        public async Task RunDetectLogic_ログ内容0件_削除のみ実行()
        {
            // Arrange
            var fileInfo = CreateFileInfo();
            _mockDataLakeService.Setup(m => m.GetLogContents(fileInfo)).Returns([]);

            // Act
            await _target.RunDetectLogic(fileInfo, [], [], []);

            // Assert
            _mockDataLakeService.Verify(m => m.DeleteLogFile(fileInfo), Times.Once);
        }

        /// <summary>
        /// 前回失敗ファイルの処理済み行より前の行がスキップされることを確認
        /// </summary>
        [TestMethod]
        public async Task RunDetectLogic_処理済み行スキップ_判定対象外()
        {
            // Arrange
            var fileInfo = CreateFileInfo();
            _mockErrorFileManager.Setup(m => m.IsExists(fileInfo)).ReturnsAsync(true);
            _mockErrorFileManager.Setup(m => m.GetErrorFile(fileInfo)).ReturnsAsync(new ErrorFile("test.json", 1, 1, false));

            _mockDataLakeService.Setup(m => m.GetLogContents(fileInfo)).Returns([
                new() { ResourceType = "cosmosdb", ResourcesToAccess = "SYS1_COSMOS", AccessDB = "db1", UserId = "u1" },
                new() { ResourceType = "cosmosdb", ResourcesToAccess = "SYS1_COSMOS", AccessDB = "db1", UserId = "u2" }
            ]);

            var conditions = new List<NotificationConditionsModel>
            {
                new() { SystemCode = "SYS1", ConditionName = "Cond1", ResourceType = "cosmosdb", ResourceName = "SYS1_COSMOS", DBName = "db1", Target = "db1", FunctionId = "F01" }
            };

            // Act
            await _target.RunDetectLogic(fileInfo, conditions, [], []);

            // Assert
            _mockAlertService.Verify(m => m.Alert(It.IsAny<string>(), It.IsAny<string>(), It.Is<string>(s => s.Contains("u2"))), Times.Once);
            _mockAlertService.Verify(m => m.Alert(It.IsAny<string>(), It.IsAny<string>(), It.Is<string>(s => s.Contains("u1"))), Times.Never);
            _mockErrorFileManager.Verify(m => m.DeleteErrorFile(fileInfo), Times.Once);
        }

        /// <summary>
        /// 1000行毎のチェックで実行時間閾値を超過した場合、例外スロー後にトレースログが出力されることを確認
        /// </summary>
        [TestMethod]
        public async Task RunDetectLogic_1000行毎閾値超過_例外スロー()
        {
            // Arrange
            var fileInfo = CreateFileInfo();
            _mockDataLakeService.Setup(m => m.GetLogContents(fileInfo)).Returns([new()]);
            int callCount = 0;
            _mockTimeManager.Setup(m => m.GetElapsedTime()).Returns(() =>
            {
                callCount++;
                return callCount == 1 ? TimeSpan.FromMinutes(1) : TimeSpan.FromMinutes(30);
            });

            // Act
            await _target.RunDetectLogic(fileInfo, [], [], []);

            // Assert
            _mockAppLogger.Verify(m => m.WriteLog(Messages.T_003, LogLevel.TRACE, It.IsAny<Exception?>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
            _mockErrorFileManager.Verify(m => m.OutputErrorFile(It.IsAny<LogFileInfoModel>(), It.IsAny<int>(), It.IsAny<bool>()), Times.Never);
        }

        /// <summary>
        /// システム操作IDに一致するユーザーの場合、非通知対象となることを確認
        /// </summary>
        [TestMethod]
        public async Task RunDetectLogic_システム操作ID登録済み_非通知()
        {
            // Arrange
            var fileInfo = CreateFileInfo();
            _mockDataLakeService.Setup(m => m.GetLogContents(fileInfo)).Returns([
                new() { ResourceType = "cosmosdb", ResourcesToAccess = "SYS1_COSMOS", AccessDB = "db1", UserId = "admin@test.com" }
            ]);
            var conditions = new List<NotificationConditionsModel>
            {
                new()
                {
                    SystemCode = "SYS1", ConditionName = "Cond1", ResourceType = "cosmosdb",
                    ResourceName = "SYS1_COSMOS", DBName = "db1", Target = "db1", FunctionId = "F01",
                    SystemOperationId = ["ADMIN@TEST.COM"]
                }
            };

            // Act
            await _target.RunDetectLogic(fileInfo, conditions, [], []);

            // Assert
            _mockAlertService.Verify(m => m.Alert(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never);
            _mockCosmosDBService.Verify(m => m.PostItem(It.IsAny<DetectionHistoryModel>(), false), Times.Once);
        }

        /// <summary>
        /// ストレージ操作がブラックリストに一致しホワイトリストにない場合、通知対象となることを確認
        /// </summary>
        [TestMethod]
        public async Task RunDetectLogic_ブラックリスト一致_通知対象()
        {
            // Arrange
            var fileInfo = CreateFileInfo();
            _mockDataLakeService.Setup(m => m.GetLogContents(fileInfo)).Returns([
                new()
                {
                    ResourceType = "blob",
                    ResourcesToAccess = "SYS1_STACC",
                    AccessTarget = "https://stacc.blob.core.windows.net/container/secret.txt",
                    AccessMethod = "BlobClient/1.0",
                    AccessOperation = "DeleteBlob",
                    UserId = "user1@test.com"
                }
            ]);

            var conditions = new List<NotificationConditionsModel>
            {
                new()
                {
                    SystemCode = "SYS1", ConditionName = "CondBlob", ResourceType = "blob",
                    ResourceName = "SYS1_STACC", Target = "/container/", FunctionId = "F01"
                }
            };
            var methods = new List<OperationMethodModel>
            {
                new() { OperationTarget = LogContentsSettings.OPERATION_TARGET_STORAGEACCOUNT, Range = "SYS1_STACC", OperationMethod = "BlobClient" }
            };
            var catalogs = new List<OperationCatalogModel>
            {
                new()
                {
                    Type = CosmosDBSettings.OPERATION_CATALOG_STORAGE,
                    BlackList = new() { Operation = ["DeleteBlob"] },
                    WhiteList = new() { Operation = ["GetBlob"] }
                }
            };

            // Act
            await _target.RunDetectLogic(fileInfo, conditions, methods, catalogs);

            // Assert
            _mockAlertService.Verify(m => m.Alert("SYS1_STACC", "F01", It.IsAny<string>()), Times.Once);
            _mockCosmosDBService.Verify(m => m.PostItem(It.IsAny<DetectionHistoryModel>(), false), Times.Once);
        }

        /// <summary>
        /// ストレージ操作がホワイトリストに一致する場合、非通知となることを確認
        /// </summary>
        [TestMethod]
        public async Task RunDetectLogic_ホワイトリスト一致_非通知()
        {
            // Arrange
            var fileInfo = CreateFileInfo();
            _mockDataLakeService.Setup(m => m.GetLogContents(fileInfo)).Returns([
                new()
                {
                    ResourceType = "blob",
                    ResourcesToAccess = "SYS1_STACC",
                    AccessTarget = "https://stacc.blob.core.windows.net/container/file.txt",
                    AccessMethod = "BlobClient/1.0",
                    AccessOperation = "GetBlob",
                    UserId = "user1@test.com"
                }
            ]);

            var conditions = new List<NotificationConditionsModel>
            {
                new() { SystemCode = "SYS1", ConditionName = "CondBlob", ResourceType = "blob", ResourceName = "SYS1_STACC", Target = "/container/", FunctionId = "F01" }
            };
            var methods = new List<OperationMethodModel>
            {
                new() { OperationTarget = LogContentsSettings.OPERATION_TARGET_STORAGEACCOUNT, Range = "SYS1", OperationMethod = "BlobClient" }
            };
            var catalogs = new List<OperationCatalogModel>
            {
                new()
                {
                    Type = CosmosDBSettings.OPERATION_CATALOG_STORAGE,
                    BlackList = new() { Operation = ["DeleteBlob"] },
                    WhiteList = new() { Operation = ["GetBlob"] }
                }
            };

            // Act
            await _target.RunDetectLogic(fileInfo, conditions, methods, catalogs);

            // Assert
            _mockAlertService.Verify(m => m.Alert(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        /// <summary>
        /// 同一条件・同一ユーザーの重複アラートは二重発報されないことを確認
        /// </summary>
        [TestMethod]
        public async Task RunDetectLogic_重複アラートあり_発報スキップ()
        {
            // Arrange
            var fileInfo = CreateFileInfo();
            var logItem = new LogContentsModel { ResourceType = "cosmosdb", ResourcesToAccess = "SYS1_COSMOS", AccessDB = "db1", UserId = "user1@test.com" };
            _mockDataLakeService.Setup(m => m.GetLogContents(fileInfo)).Returns([logItem, logItem]);

            var conditions = new List<NotificationConditionsModel>
            {
                new() { SystemCode = "SYS1", ConditionName = "Cond1", ResourceType = "cosmosdb", ResourceName = "SYS1_COSMOS", DBName = "db1", Target = "db1", FunctionId = "F01" }
            };

            // Act
            await _target.RunDetectLogic(fileInfo, conditions, [], []);

            // Assert
            _mockAlertService.Verify(m => m.Alert(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);
            _mockCosmosDBService.Verify(m => m.PostItem(It.IsAny<DetectionHistoryModel>(), false), Times.Exactly(2));
        }

        /// <summary>
        /// CosmosDBコンテナの場合、UPN変換が実行されユーザーIDが空ならUnknownでアラート発報されることを確認
        /// </summary>
        [TestMethod]
        public async Task RunDetectLogic_CosmosDBコンテナ該当_UPN変換実行()
        {
            // Arrange
            var fileInfo = CreateFileInfo("cosmosdb-container");
            _mockDataLakeService.Setup(m => m.GetLogContents(fileInfo)).Returns([
                new() { ResourceType = "cosmosdb", ResourcesToAccess = "SYS1_COSMOS", AccessDB = "db1", UserId = "oid-123" }
            ]);
            _mockUserAccountManager.Setup(m => m.GetUPN("oid-123")).Returns("-");

            var conditions = new List<NotificationConditionsModel>
            {
                new() { SystemCode = "SYS1", ConditionName = "Cond1", ResourceType = "cosmosdb", ResourceName = "SYS1_COSMOS", DBName = "db1", Target = "db1", FunctionId = "F01" }
            };

            // Act
            await _target.RunDetectLogic(fileInfo, conditions, [], []);

            // Assert
            _mockUserAccountManager.Verify(m => m.GetUPN("oid-123"), Times.Once);
            _mockAlertService.Verify(m => m.Alert("SYS1_COSMOS", "F01", It.Is<string>(msg => msg.Contains("Unknown"))), Times.Once);
        }

        /// <summary>
        /// アラート送信時に例外が発生した場合、エラーファイルとトレースログが出力されることを確認
        /// </summary>
        [TestMethod]
        public async Task RunDetectLogic_アラート送信例外_エラーファイル出力()
        {
            // Arrange
            var fileInfo = CreateFileInfo();
            _mockDataLakeService.Setup(m => m.GetLogContents(fileInfo)).Returns([
                new() { ResourceType = "cosmosdb", ResourcesToAccess = "SYS1_COSMOS", AccessDB = "db1", UserId = "u1" }
            ]);
            var conditions = new List<NotificationConditionsModel>
            {
                new() { SystemCode = "SYS1", ConditionName = "Cond1", ResourceType = "cosmosdb", ResourceName = "SYS1_COSMOS", DBName = "db1", Target = "db1", FunctionId = "F01" }
            };
            _mockAlertService.Setup(m => m.Alert(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Throws(new Exception("アラート失敗"));

            // Act
            await _target.RunDetectLogic(fileInfo, conditions, [], []);

            // Assert
            _mockErrorFileManager.Verify(m => m.OutputErrorFile(fileInfo, 0, false), Times.Once);
            _mockAppLogger.Verify(m => m.WriteLog(Messages.T_004, LogLevel.TRACE, It.IsAny<Exception?>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// 検知履歴登録時に例外が発生した場合、notificationFlag=trueでエラーファイルが出力されることを確認
        /// </summary>
        [TestMethod]
        public async Task RunDetectLogic_検知履歴登録例外_エラーファイル出力()
        {
            // Arrange
            var fileInfo = CreateFileInfo();
            _mockDataLakeService.Setup(m => m.GetLogContents(fileInfo)).Returns([
                new() { ResourceType = "cosmosdb", ResourcesToAccess = "SYS1_COSMOS", AccessDB = "db1", UserId = "u1" }
            ]);
            var conditions = new List<NotificationConditionsModel>
            {
                new() { SystemCode = "SYS1", ConditionName = "Cond1", ResourceType = "cosmosdb", ResourceName = "SYS1_COSMOS", DBName = "db1", Target = "db1", FunctionId = "F01" }
            };
            _mockCosmosDBService.Setup(m => m.PostItem(It.IsAny<DetectionHistoryModel>(), false)).ThrowsAsync(new Exception("DB登録失敗"));

            // Act
            await _target.RunDetectLogic(fileInfo, conditions, [], []);

            // Assert
            _mockErrorFileManager.Verify(m => m.OutputErrorFile(fileInfo, 0, true), Times.Once);
            _mockAppLogger.Verify(m => m.WriteLog(Messages.T_005, LogLevel.TRACE, It.IsAny<Exception?>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// 前回失敗ファイル削除時に例外が発生した場合、エラーファイルとトレースログが出力されることを確認
        /// </summary>
        [TestMethod]
        public async Task RunDetectLogic_失敗ファイル削除例外_エラー出力()
        {
            // Arrange
            var fileInfo = CreateFileInfo();
            _mockErrorFileManager.Setup(m => m.IsExists(fileInfo)).ReturnsAsync(true);
            _mockErrorFileManager.Setup(m => m.GetErrorFile(fileInfo)).ReturnsAsync(new ErrorFile("test.json", 0, 1, false));
            _mockDataLakeService.Setup(m => m.GetLogContents(fileInfo)).Returns([]);
            _mockErrorFileManager.Setup(m => m.DeleteErrorFile(fileInfo)).ThrowsAsync(new Exception("削除失敗"));

            // Act
            await _target.RunDetectLogic(fileInfo, [], [], []);

            // Assert
            _mockErrorFileManager.Verify(m => m.OutputErrorFile(fileInfo, 0, true), Times.Once);
            _mockAppLogger.Verify(m => m.WriteLog(Messages.T_006, LogLevel.TRACE, It.IsAny<Exception?>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }
    }
}
