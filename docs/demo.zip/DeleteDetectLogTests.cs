﻿using Moq;
using NotificationFunction.Logic.Detect;
using NotificationFunction.Models.DataLake;
using NotificationFunction.Service.DataLake.Interfaces;
using NotificationFunction.Service.Error.Interfaces;

namespace NotificationFunction.Tests.Logic.Detect
{
    /// <summary>
    /// DeleteDetectLogの単体テストクラス
    /// </summary>
    [TestClass]
    public class DeleteDetectLogTests
    {
        private Mock<IErrorFileManager> _mockErrorFileManager = null!;
        private Mock<IDataLakeService> _mockDataLakeService = null!;
        private DeleteDetectLog _target = null!;

        [TestInitialize]
        public void Setup()
        {
            _mockErrorFileManager = new Mock<IErrorFileManager>();
            _mockDataLakeService = new Mock<IDataLakeService>();
            _target = new DeleteDetectLog(_mockErrorFileManager.Object, _mockDataLakeService.Object);
        }

        /// <summary>
        /// ログリストが0件の場合、削除処理が実行されないことを確認
        /// </summary>
        [TestMethod]
        public async Task DeleteLog_ログリスト0件()
        {
            // Arrange
            var logInfoList = new List<LogFileInfoModel>();

            // Act
            await _target.DeleteLog(logInfoList);

            // Assert
            _mockErrorFileManager.Verify(m => m.IsExists(It.IsAny<LogFileInfoModel>()), Times.Never);
            _mockDataLakeService.Verify(m => m.DeleteLogFile(It.IsAny<LogFileInfoModel>()), Times.Never);
        }

        /// <summary>
        /// 前回失敗ファイルが存在しない場合、ログファイルが削除されることを確認
        /// </summary>
        [TestMethod]
        public async Task DeleteLog_前回失敗ファイルなし_削除実行()
        {
            // Arrange
            var logInfo = new LogFileInfoModel { ContainerName = "test", DirectoryPath = "dir/", FileName = "test.json" };
            var logInfoList = new List<LogFileInfoModel> { logInfo };
            _mockErrorFileManager.Setup(m => m.IsExists(logInfo)).ReturnsAsync(false);

            // Act
            await _target.DeleteLog(logInfoList);
            await Task.Delay(50);

            // Assert
            _mockDataLakeService.Verify(m => m.DeleteLogFile(logInfo), Times.Once);
        }

        /// <summary>
        /// 前回失敗ファイルが存在する場合、ログファイルが削除されないことを確認
        /// </summary>
        [TestMethod]
        public async Task DeleteLog_前回失敗ファイルあり_削除スキップ()
        {
            // Arrange
            var logInfo = new LogFileInfoModel { ContainerName = "test", DirectoryPath = "dir/", FileName = "test.json" };
            var logInfoList = new List<LogFileInfoModel> { logInfo };
            _mockErrorFileManager.Setup(m => m.IsExists(logInfo)).ReturnsAsync(true);

            // Act
            await _target.DeleteLog(logInfoList);
            await Task.Delay(50);

            // Assert
            _mockDataLakeService.Verify(m => m.DeleteLogFile(It.IsAny<LogFileInfoModel>()), Times.Never);
        }

        /// <summary>
        /// 複数件混在している場合、前回失敗ファイルが存在しない対象のみ削除されることを確認
        /// </summary>
        [TestMethod]
        public async Task DeleteLog_複数件混在_対象のみ削除()
        {
            // Arrange
            var log1 = new LogFileInfoModel { FileName = "1.json" };
            var log2 = new LogFileInfoModel { FileName = "2.json" };
            var log3 = new LogFileInfoModel { FileName = "3.json" };
            var logInfoList = new List<LogFileInfoModel> { log1, log2, log3 };

            _mockErrorFileManager.Setup(m => m.IsExists(log1)).ReturnsAsync(false);
            _mockErrorFileManager.Setup(m => m.IsExists(log2)).ReturnsAsync(true);
            _mockErrorFileManager.Setup(m => m.IsExists(log3)).ReturnsAsync(false);

            // Act
            await _target.DeleteLog(logInfoList);
            await Task.Delay(50);

            // Assert
            _mockDataLakeService.Verify(m => m.DeleteLogFile(log1), Times.Once);
            _mockDataLakeService.Verify(m => m.DeleteLogFile(log2), Times.Never);
            _mockDataLakeService.Verify(m => m.DeleteLogFile(log3), Times.Once);
        }

        /// <summary>
        /// ログリストが最大件数（100件）の場合、全件正常に処理されることを確認
        /// </summary>
        [TestMethod]
        public async Task DeleteLog_ログリスト最大件数()
        {
            // Arrange
            var logInfoList = Enumerable.Range(1, 100)
                .Select(i => new LogFileInfoModel { FileName = $"log_{i}.json" })
                .ToList();
            _mockErrorFileManager.Setup(m => m.IsExists(It.IsAny<LogFileInfoModel>())).ReturnsAsync(false);

            // Act
            await _target.DeleteLog(logInfoList);
            await Task.Delay(100);

            // Assert
            _mockDataLakeService.Verify(m => m.DeleteLogFile(It.IsAny<LogFileInfoModel>()), Times.Exactly(100));
        }
    }
}
