﻿using Moq;
using NotificationFunction.Models.DataLake;
using NotificationFunction.Resources;
using NotificationFunction.Service.DataLake;
using NotificationFunction.Service.Logger.Interfaces;
using System.Reflection;

namespace NotificationFunction.Tests.Service.DataLake
{
    /// <summary>
    /// DataLakeServiceの単体テストクラス
    /// </summary>
    [TestClass]
    public class DataLakeServiceTests
    {
        private Mock<IAPPLogger> _mockAppLogger = null!;
        private Mock<IAlertService> _mockAlertService = null!;
        private DataLakeService _target = null!;

        [TestInitialize]
        public void Setup()
        {
            Environment.SetEnvironmentVariable(EnvironmentValue.DATALAKE_CONNECTION_STRING, "UseDevelopmentStorage=true");
            Environment.SetEnvironmentVariable(EnvironmentValue.DATALAKE_TEMP_FILE_PATH, Path.GetTempPath());
            Environment.SetEnvironmentVariable(EnvironmentValue.DATALAKE_STORAGEACCOUNT_CONTAINER_NAMES, "storage-container");
            Environment.SetEnvironmentVariable(EnvironmentValue.DATALAKE_SQLMI_CONTAINER_NAMES, "sqlmi-container");
            Environment.SetEnvironmentVariable(EnvironmentValue.DATALAKE_SQLDB_CONTAINER_NAMES, "sqldb-container");
            Environment.SetEnvironmentVariable(EnvironmentValue.DATALAKE_COSMOSDBACCOUNT_CONTAINER_NAMES, "cosmosdb-container");

            _mockAppLogger = new Mock<IAPPLogger>();
            _mockAlertService = new Mock<IAlertService>();
            _target = new DataLakeService(_mockAppLogger.Object, _mockAlertService.Object);
        }

        private static LogContentsModel InvokeMappingStorageAccount(string line, string directoryPath)
        {
            var method = typeof(DataLakeService).GetMethod("MappingModelStorageAccount", BindingFlags.Static | BindingFlags.NonPublic)!;
            return (LogContentsModel)method.Invoke(null, [line, directoryPath])!;
        }

        private static LogContentsModel InvokeMappingCosmosDB(string line)
        {
            var method = typeof(DataLakeService).GetMethod("MappingModelCosmosDB", BindingFlags.Static | BindingFlags.NonPublic)!;
            return (LogContentsModel)method.Invoke(null, [line])!;
        }

        /// <summary>
        /// リネーム対象リストが0件の場合、空リストがそのまま返却されることを確認
        /// </summary>
        [TestMethod]
        public void RenameLogFile_ファイルリスト0件_空リスト返却()
        {
            // Arrange
            var list = new List<LogFileInfoModel>();

            // Act
            var result = _target.RenameLogFile(list);

            // Assert
            Assert.AreEqual(0, result.Count);
        }

        /// <summary>
        /// 既にリネーム済みのファイル(yyyyMMddHHmm_形式)の場合、リネーム処理がスキップされることを確認
        /// </summary>
        [TestMethod]
        public void RenameLogFile_リネーム済みファイル_スキップ()
        {
            // Arrange
            var model = new LogFileInfoModel
            {
                ContainerName = "storage-container",
                DirectoryPath = "dir/",
                FileName = "202611131200_PT1H.json"
            };
            var list = new List<LogFileInfoModel> { model };

            // Act
            var result = _target.RenameLogFile(list);

            // Assert
            Assert.AreEqual("202611131200_PT1H.json", result[0].FileName);
        }

        /// <summary>
        /// ストレージアカウントログのマッピング時、UPNあり・Blobパス一致の場合に正しく設定されることを確認
        /// </summary>
        [TestMethod]
        public void GetLogContents_ストレージアカウント_UPNあり_Blob種別設定()
        {
            // Arrange
            string json = "{\"time\":\"2026-11-13T10:00:00Z\",\"callerIpAddress\":\"192.168.1.1\",\"operationName\":\"GetBlob\",\"uri\":\"https://acc.blob.core.windows.net/c/test.txt\",\"identity\":{\"requester\":{\"upn\":\"user@example.com\"}},\"properties\":{\"accountName\":\"acc\",\"userAgentHeader\":\"AzureStorage\"}}";

            // Act
            var result = InvokeMappingStorageAccount(json, "subscriptions/sub/blobServices/default");

            // Assert
            Assert.AreEqual("user@example.com", result.UserId);
            Assert.AreEqual("blob", result.ResourceType);
        }

        /// <summary>
        /// ストレージアカウントログのマッピング時、UPNが空文字・Fileパス一致の場合に"-"と"file"が設定されることを確認
        /// </summary>
        [TestMethod]
        public void GetLogContents_ストレージアカウント_UPN空文字_File種別設定()
        {
            // Arrange
            string json = "{\"time\":\"2026-11-13T10:00:00Z\",\"operationName\":\"GetFile\",\"uri\":\"https://acc.file.core.windows.net/s/test.txt\",\"identity\":{\"requester\":{\"upn\":\"\"}},\"properties\":{\"accountName\":\"acc\"}}";

            // Act
            var result = InvokeMappingStorageAccount(json, "subscriptions/sub/fileServices/default");

            // Assert
            Assert.AreEqual("-", result.UserId);
            Assert.AreEqual("file", result.ResourceType);
        }

        /// <summary>
        /// ストレージアカウントログのマッピング時、IdentityがnullでNullReferenceExceptionが発生した場合に"-"と"table"が設定されることを確認
        /// </summary>
        [TestMethod]
        public void GetLogContents_ストレージアカウント_UPN取得Null例外_Table種別設定()
        {
            // Arrange
            string json = "{\"time\":\"2026-11-13T10:00:00Z\",\"operationName\":\"QueryEntity\",\"uri\":\"https://acc.table.core.windows.net/t\",\"properties\":{\"accountName\":\"acc\"}}";

            // Act
            var result = InvokeMappingStorageAccount(json, "subscriptions/sub/tableServices/default");

            // Assert
            Assert.AreEqual("-", result.UserId);
            Assert.AreEqual("table", result.ResourceType);
        }

        /// <summary>
        /// CosmosDBログのマッピング時、ユーザーIDが存在する場合にそのまま設定されることを確認
        /// </summary>
        [TestMethod]
        public void GetLogContents_CosmosDB_ユーザーIDあり_正常マッピング()
        {
            // Arrange
            string json = "{\"time\":\"2026-11-13T10:00:00Z\",\"resourceId\":\"/subscriptions/sub/resourceGroups/rg/providers/Microsoft.DocumentDB/databaseAccounts/cosmos01\",\"operationName\":\"Read\",\"properties\":{\"aadPrincipalId\":\"oid-999\",\"databaseName\":\"db1\",\"collectionName\":\"col1\"}}";

            // Act
            var result = InvokeMappingCosmosDB(json);

            // Assert
            Assert.AreEqual("oid-999", result.UserId);
            Assert.AreEqual("cosmos01", result.ResourcesToAccess);
            Assert.AreEqual("cosmosdb", result.ResourceType);
        }

        /// <summary>
        /// CosmosDBログのマッピング時、ユーザーIDが空の場合にハイフン("-")が設定されることを確認
        /// </summary>
        [TestMethod]
        public void GetLogContents_CosmosDB_ユーザーID空_ハイフン設定()
        {
            // Arrange
            string json = "{\"time\":\"2026-11-13T10:00:00Z\",\"resourceId\":\"/subscriptions/sub/resourceGroups/rg/providers/Microsoft.DocumentDB/databaseAccounts/cosmos01\",\"operationName\":\"Read\",\"properties\":{\"aadPrincipalId\":\"\",\"databaseName\":\"db1\",\"collectionName\":\"col1\"}}";

            // Act
            var result = InvokeMappingCosmosDB(json);

            // Assert
            Assert.AreEqual("-", result.UserId);
        }
    }
}
