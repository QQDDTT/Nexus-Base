﻿using Moq;
using NotificationFunction.Logic.Detect;
using NotificationFunction.Models.DataLake;
using NotificationFunction.Service.DataLake.Interfaces;

namespace NotificationFunction.Tests.Logic.Detect
{
    /// <summary>
    /// GetDetectLogの単体テストクラス
    /// </summary>
    [TestClass]
    public class GetDetectLogTests
    {
        private Mock<IDataLakeService> _mockDataLakeService = null!;
        private GetDetectLog _target = null!;

        [TestInitialize]
        public void Setup()
        {
            _mockDataLakeService = new Mock<IDataLakeService>();
            _target = new GetDetectLog(_mockDataLakeService.Object);
        }

        /// <summary>
        /// ログ一覧を正常に取得できることを確認
        /// </summary>
        [TestMethod]
        public void Initialize_ログ一覧取得_正常終了()
        {
            // Arrange
            var logs = new List<LogFileInfoModel> { new() { FileName = "test.json" } };
            _mockDataLakeService.Setup(m => m.GetLogFileList()).Returns(logs);

            // Act
            _target.Initialize();

            // Assert
            _mockDataLakeService.Verify(m => m.GetLogFileList(), Times.Once);
        }

        /// <summary>
        /// ログ一覧が0件の場合でも正常終了することを確認
        /// </summary>
        [TestMethod]
        public void Initialize_ログ一覧0件_正常終了()
        {
            // Arrange
            _mockDataLakeService.Setup(m => m.GetLogFileList()).Returns([]);

            // Act
            _target.Initialize();

            // Assert
            _mockDataLakeService.Verify(m => m.GetLogFileList(), Times.Once);
        }

        /// <summary>
        /// ログリストが0件の場合、リネーム対象として空リストが返却されることを確認
        /// </summary>
        [TestMethod]
        public async Task GetRenameLogList_ログリスト0件_空リスト返却()
        {
            // Arrange
            _mockDataLakeService.Setup(m => m.GetLogFileList()).Returns([]);
            _mockDataLakeService.Setup(m => m.RenameLogFile(It.IsAny<List<LogFileInfoModel>>())).Returns([]);
            _target.Initialize();

            // Act
            var result = await _target.GetRenameLogList();

            // Assert
            Assert.AreEqual(0, result.Count);
        }

        /// <summary>
        /// .xel以外のファイルのみ存在する場合、全件リネーム対象として取得されることを確認
        /// </summary>
        [TestMethod]
        public async Task GetRenameLogList_xel以外のファイルあり_リネーム対象取得()
        {
            // Arrange
            var logs = new List<LogFileInfoModel>
            {
                new() { FileName = "test1.log" },
                new() { FileName = "test2.json" }
            };
            _mockDataLakeService.Setup(m => m.GetLogFileList()).Returns(logs);
            _mockDataLakeService.Setup(m => m.RenameLogFile(It.Is<List<LogFileInfoModel>>(l => l.Count == 2))).Returns(logs);
            _target.Initialize();

            // Act
            var result = await _target.GetRenameLogList();

            // Assert
            Assert.AreEqual(2, result.Count);
        }

        /// <summary>
        /// .xelファイルのみ存在する場合、リネーム対象が0件となることを確認
        /// </summary>
        [TestMethod]
        public async Task GetRenameLogList_xelファイルのみ_リネーム対象なし()
        {
            // Arrange
            var logs = new List<LogFileInfoModel>
            {
                new() { FileName = "test1.xel" },
                new() { FileName = "test2.xel" }
            };
            _mockDataLakeService.Setup(m => m.GetLogFileList()).Returns(logs);
            _mockDataLakeService.Setup(m => m.RenameLogFile(It.Is<List<LogFileInfoModel>>(l => l.Count == 0))).Returns([]);
            _target.Initialize();

            // Act
            var result = await _target.GetRenameLogList();

            // Assert
            Assert.AreEqual(0, result.Count);
        }

        /// <summary>
        /// .xelとその他のファイルが混在する場合、.xel以外のみ抽出されることを確認
        /// </summary>
        [TestMethod]
        public async Task GetRenameLogList_xelとその他混在_xel以外のみ抽出()
        {
            // Arrange
            var logs = new List<LogFileInfoModel>
            {
                new() { FileName = "a.xel" },
                new() { FileName = "b.log" },
                new() { FileName = "c.csv" }
            };
            _mockDataLakeService.Setup(m => m.GetLogFileList()).Returns(logs);
            _mockDataLakeService.Setup(m => m.RenameLogFile(It.IsAny<List<LogFileInfoModel>>()))
                .Returns<List<LogFileInfoModel>>(list => list);
            _target.Initialize();

            // Act
            var result = await _target.GetRenameLogList();

            // Assert
            Assert.AreEqual(2, result.Count);
            Assert.IsTrue(result.All(r => r.FileName != "a.xel"));
        }

        /// <summary>
        /// ログリストが最大件数（1000件）の場合でも正常に処理されることを確認
        /// </summary>
        [TestMethod]
        public async Task GetRenameLogList_ログリスト最大件数_正常終了()
        {
            // Arrange
            var logs = Enumerable.Range(1, 1000)
                .Select(i => new LogFileInfoModel { FileName = $"file_{i}.json" })
                .ToList();
            _mockDataLakeService.Setup(m => m.GetLogFileList()).Returns(logs);
            _mockDataLakeService.Setup(m => m.RenameLogFile(It.IsAny<List<LogFileInfoModel>>())).Returns(logs);
            _target.Initialize();

            // Act
            var result = await _target.GetRenameLogList();

            // Assert
            Assert.AreEqual(1000, result.Count);
        }

        /// <summary>
        /// ログリストが0件の場合、XELリストとして空リストが返却されることを確認
        /// </summary>
        [TestMethod]
        public async Task GetXelLogList_ログリスト0件_空リスト返却()
        {
            // Arrange
            _mockDataLakeService.Setup(m => m.GetLogFileList()).Returns([]);
            _target.Initialize();

            // Act
            var result = await _target.GetXelLogList();

            // Assert
            Assert.AreEqual(0, result.Count);
        }

        /// <summary>
        /// .xelファイルが複数件存在する場合、更新日時の昇順でソートされることを確認
        /// </summary>
        [TestMethod]
        public async Task GetXelLogList_xelファイル複数件_更新日時昇順ソート()
        {
            // Arrange
            var t1 = new DateTimeOffset(2026, 11, 13, 10, 1, 0, TimeSpan.Zero);
            var t2 = new DateTimeOffset(2026, 11, 13, 10, 3, 0, TimeSpan.Zero);
            var t3 = new DateTimeOffset(2026, 11, 13, 10, 5, 0, TimeSpan.Zero);

            var logs = new List<LogFileInfoModel>
            {
                new() { FileName = "3.xel", LastModified = t3 },
                new() { FileName = "1.xel", LastModified = t1 },
                new() { FileName = "2.xel", LastModified = t2 }
            };
            _mockDataLakeService.Setup(m => m.GetLogFileList()).Returns(logs);
            _target.Initialize();

            // Act
            var result = await _target.GetXelLogList();

            // Assert
            Assert.AreEqual(3, result.Count);
            Assert.AreEqual("1.xel", result[0].FileName);
            Assert.AreEqual("2.xel", result[1].FileName);
            Assert.AreEqual("3.xel", result[2].FileName);
        }

        /// <summary>
        /// .xel以外のファイルのみ存在する場合、空リストが返却されることを確認
        /// </summary>
        [TestMethod]
        public async Task GetXelLogList_xel以外のファイルのみ_空リスト返却()
        {
            // Arrange
            var logs = new List<LogFileInfoModel>
            {
                new() { FileName = "test1.log" },
                new() { FileName = "test2.txt" }
            };
            _mockDataLakeService.Setup(m => m.GetLogFileList()).Returns(logs);
            _target.Initialize();

            // Act
            var result = await _target.GetXelLogList();

            // Assert
            Assert.AreEqual(0, result.Count);
        }

        /// <summary>
        /// .xelとその他のファイルが混在する場合、.xelのみ抽出されることを確認
        /// </summary>
        [TestMethod]
        public async Task GetXelLogList_xelとその他混在_xelのみ抽出()
        {
            // Arrange
            var logs = new List<LogFileInfoModel>
            {
                new() { FileName = "a.xel", LastModified = DateTimeOffset.UtcNow },
                new() { FileName = "b.log", LastModified = DateTimeOffset.UtcNow },
                new() { FileName = "c.xel", LastModified = DateTimeOffset.UtcNow }
            };
            _mockDataLakeService.Setup(m => m.GetLogFileList()).Returns(logs);
            _target.Initialize();

            // Act
            var result = await _target.GetXelLogList();

            // Assert
            Assert.AreEqual(2, result.Count);
            Assert.IsTrue(result.All(r => r.FileName!.EndsWith(".xel")));
        }

        /// <summary>
        /// ログリストが最大件数（1000件）の場合でも正常にソート・返却されることを確認
        /// </summary>
        [TestMethod]
        public async Task GetXelLogList_ログリスト最大件数_正常終了()
        {
            // Arrange
            var baseTime = DateTimeOffset.UtcNow;
            var logs = Enumerable.Range(1, 1000)
                .Select(i => new LogFileInfoModel { FileName = $"file_{i}.xel", LastModified = baseTime.AddSeconds(-i) })
                .ToList();
            _mockDataLakeService.Setup(m => m.GetLogFileList()).Returns(logs);
            _target.Initialize();

            // Act
            var result = await _target.GetXelLogList();

            // Assert
            Assert.AreEqual(1000, result.Count);
            Assert.AreEqual("file_1000.xel", result[0].FileName);
        }
    }
}
