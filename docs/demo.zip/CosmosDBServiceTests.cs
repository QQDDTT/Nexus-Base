﻿using Microsoft.Azure.Cosmos;
using Moq;
using NotificationFunction.Models.CosmosDB;
using NotificationFunction.Resources;
using NotificationFunction.Service.CosmosDB;
using NotificationFunction.Service.Logger.Interfaces;

namespace NotificationFunction.Tests.Service.CosmosDB
{
    /// <summary>
    /// CosmosDBServiceの単体テストクラス
    /// </summary>
    [TestClass]
    public class CosmosDBServiceTests
    {
        private Mock<IAPPLogger> _mockAppLogger = null!;
        private Mock<CosmosClient> _mockCosmosClient = null!;
        private Mock<Container> _mockContainer = null!;
        private CosmosDBService _target = null!;

        [TestInitialize]
        public void Setup()
        {
            _mockAppLogger = new Mock<IAPPLogger>();
            _mockCosmosClient = new Mock<CosmosClient>();
            _mockContainer = new Mock<Container>();

            _mockCosmosClient
                .Setup(c => c.GetContainer(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(_mockContainer.Object);

            _target = new CosmosDBService(_mockAppLogger.Object, _mockCosmosClient.Object);
        }

        /// <summary>
        /// DetectionHistoryModelを指定して新規登録(overwrite=false)が正常に実行されることを確認
        /// </summary>
        [TestMethod]
        public async Task PostItem_DetectionHistoryModel_新規登録()
        {
            // Arrange
            var item = new DetectionHistoryModel();

            // Act
            await _target.PostItem(item, false);

            // Assert
            _mockCosmosClient.Verify(c => c.GetContainer(CosmosDBSettings.DATABASE_NAME, CosmosDBSettings.TABLE_NAME_DETECTION), Times.Once);
            _mockContainer.Verify(c => c.CreateItemAsync(item, null, null, default), Times.Once);
            _mockContainer.Verify(c => c.UpsertItemAsync(It.IsAny<DetectionHistoryModel>(), It.IsAny<PartitionKey?>(), null, default), Times.Never);
        }

        /// <summary>
        /// UserIdManagementModelを指定して上書き更新(overwrite=true)が正常に実行されることを確認
        /// </summary>
        [TestMethod]
        public async Task PostItem_UserIdManagementModel_上書き更新()
        {
            // Arrange
            var item = new UserIdManagementModel();

            // Act
            await _target.PostItem(item, true);

            // Assert
            _mockCosmosClient.Verify(c => c.GetContainer(CosmosDBSettings.DATABASE_NAME, CosmosDBSettings.TABLE_NAME_USER_ID_MANAGEMENT), Times.Once);
            _mockContainer.Verify(c => c.UpsertItemAsync(item, new PartitionKey(CosmosDBSettings.PARTITION_KEY), null, default), Times.Once);
        }

        /// <summary>
        /// 対象外のモデル型を指定した場合、コンテナ未設定により例外がスローされることを確認
        /// </summary>
        [TestMethod]
        public async Task PostItem_対象外モデル型_コンテナ未設定例外()
        {
            // Arrange
            var item = new OperationMethodModel();

            // Act & Assert
            await Assert.ThrowsExceptionAsync<NullReferenceException>(() => _target.PostItem(item));
            _mockAppLogger.Verify(l => l.WriteLog(Messages.E_003, LogLevel.ERROR, It.IsAny<Exception?>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// コンテナ設定済みの状態で2回連続呼び出した場合、GetContainerが再実行されないことを確認
        /// </summary>
        [TestMethod]
        public async Task PostItem_コンテナ設定済み_再取得スキップ()
        {
            // Arrange
            var item = new DetectionHistoryModel();

            // Act
            await _target.PostItem(item);
            await _target.PostItem(item);

            // Assert
            _mockCosmosClient.Verify(c => c.GetContainer(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }

        /// <summary>
        /// DB登録時に例外が発生した場合、エラーログ出力後に例外が再スローされることを確認
        /// </summary>
        [TestMethod]
        public async Task PostItem_DB登録例外_ログ出力_再スロー()
        {
            // Arrange
            var item = new DetectionHistoryModel();
            _mockContainer.Setup(c => c.CreateItemAsync(item, null, null, default))
                .ThrowsAsync(new Exception("DB書き込みエラー"));

            // Act & Assert
            await Assert.ThrowsExceptionAsync<Exception>(() => _target.PostItem(item));
            _mockAppLogger.Verify(l => l.WriteLog(Messages.E_003, LogLevel.ERROR, It.IsAny<Exception?>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }

        private void SetupFeedIterator<T>(params List<T>[] pages)
        {
            var mockIterator = new Mock<FeedIterator<T>>();
            int index = 0;

            mockIterator.Setup(i => i.HasMoreResults).Returns(() => index < pages.Length);
            mockIterator.Setup(i => i.ReadNextAsync(default)).ReturnsAsync(() =>
            {
                var currentItems = pages[index++];
                var mockResponse = new Mock<FeedResponse<T>>();
                mockResponse.As<IEnumerable<T>>().Setup(r => r.GetEnumerator()).Returns(() => currentItems.GetEnumerator());
                return mockResponse.Object;
            });

            _mockContainer.Setup(c => c.GetItemQueryIterator<T>(
                It.IsAny<QueryDefinition>(),
                It.IsAny<string>(),
                It.IsAny<QueryRequestOptions>()))
                .Returns(mockIterator.Object);
        }

        /// <summary>
        /// OperationMethodModelの全件取得が正常に動作することを確認
        /// </summary>
        [TestMethod]
        public async Task GetAllItemList_OperationMethodModel_全件取得()
        {
            // Arrange
            SetupFeedIterator(new List<OperationMethodModel> { new(), new() });

            // Act
            var result = await _target.GetAllItemList<OperationMethodModel>();

            // Assert
            _mockCosmosClient.Verify(c => c.GetContainer(CosmosDBSettings.DATABASE_NAME, CosmosDBSettings.TABLE_NAME_OPERATION), Times.Once);
            Assert.AreEqual(2, result.Count);
        }

        /// <summary>
        /// NotificationConditionsModelの全件取得が正常に動作することを確認
        /// </summary>
        [TestMethod]
        public async Task GetAllItemList_NotificationConditionsModel_全件取得()
        {
            // Arrange
            SetupFeedIterator(new List<NotificationConditionsModel> { new() });

            // Act
            var result = await _target.GetAllItemList<NotificationConditionsModel>();

            // Assert
            _mockCosmosClient.Verify(c => c.GetContainer(CosmosDBSettings.DATABASE_NAME, CosmosDBSettings.TABLE_NAME_NOTIFICATION), Times.Once);
            Assert.AreEqual(1, result.Count);
        }

        /// <summary>
        /// OperationCatalogModelの全件取得が正常に動作することを確認
        /// </summary>
        [TestMethod]
        public async Task GetAllItemList_OperationCatalogModel_全件取得()
        {
            // Arrange
            SetupFeedIterator(new List<OperationCatalogModel> { new() });

            // Act
            var result = await _target.GetAllItemList<OperationCatalogModel>();

            // Assert
            _mockCosmosClient.Verify(c => c.GetContainer(CosmosDBSettings.DATABASE_NAME, CosmosDBSettings.TABLE_NAME_OPERATION_CATALOG), Times.Once);
            Assert.AreEqual(1, result.Count);
        }

        /// <summary>
        /// UserIdManagementModelの全件取得が正常に動作することを確認
        /// </summary>
        [TestMethod]
        public async Task GetAllItemList_UserIdManagementModel_全件取得()
        {
            // Arrange
            SetupFeedIterator(new List<UserIdManagementModel> { new() });

            // Act
            var result = await _target.GetAllItemList<UserIdManagementModel>();

            // Assert
            _mockCosmosClient.Verify(c => c.GetContainer(CosmosDBSettings.DATABASE_NAME, CosmosDBSettings.TABLE_NAME_USER_ID_MANAGEMENT), Times.Once);
            Assert.AreEqual(1, result.Count);
        }

        /// <summary>
        /// 対象外モデル型を指定した場合、コンテナ未設定により例外がスローされることを確認
        /// </summary>
        [TestMethod]
        public async Task GetAllItemList_対象外モデル型_コンテナ未設定例外()
        {
            // Act & Assert
            await Assert.ThrowsExceptionAsync<NullReferenceException>(() => _target.GetAllItemList<DetectionHistoryModel>());
            _mockAppLogger.Verify(l => l.WriteLog(Messages.E_004, LogLevel.ERROR, It.IsAny<Exception?>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// データが0件(HasMoreResults=false)の場合、空リストが返却されることを確認
        /// </summary>
        [TestMethod]
        public async Task GetAllItemList_データ0件_空リスト返却()
        {
            // Arrange
            SetupFeedIterator<OperationMethodModel>();

            // Act
            var result = await _target.GetAllItemList<OperationMethodModel>();

            // Assert
            Assert.AreEqual(0, result.Count);
        }

        /// <summary>
        /// 複数ページ・最大件数(1000件)のデータが全件結合されて返却されることを確認
        /// </summary>
        [TestMethod]
        public async Task GetAllItemList_複数ページ最大件数_全件結合返却()
        {
            // Arrange
            var page1 = Enumerable.Range(1, 500).Select(_ => new OperationMethodModel()).ToList();
            var page2 = Enumerable.Range(1, 500).Select(_ => new OperationMethodModel()).ToList();
            SetupFeedIterator(page1, page2);

            // Act
            var result = await _target.GetAllItemList<OperationMethodModel>();

            // Assert
            Assert.AreEqual(1000, result.Count);
        }

        /// <summary>
        /// DB取得時に例外が発生した場合、エラーログ出力後に例外が再スローされることを確認
        /// </summary>
        [TestMethod]
        public async Task GetAllItemList_DB取得例外_ログ出力_再スロー()
        {
            // Arrange
            _mockContainer.Setup(c => c.GetItemQueryIterator<OperationMethodModel>(
                It.IsAny<QueryDefinition>(), It.IsAny<string>(), It.IsAny<QueryRequestOptions>()))
                .Throws(new Exception("DB読み取りエラー"));

            // Act & Assert
            await Assert.ThrowsExceptionAsync<Exception>(() => _target.GetAllItemList<OperationMethodModel>());
            _mockAppLogger.Verify(l => l.WriteLog(Messages.E_004, LogLevel.ERROR, It.IsAny<Exception?>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }
    }
}
