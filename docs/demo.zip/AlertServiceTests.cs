﻿using AP01.API;
using Moq;
using NotificationFunction.Resources;
using NotificationFunction.Service.Logger;
using NotificationFunction.Service.Logger.Interfaces;
using System.Reflection;

namespace NotificationFunction.Tests.Service.Logger
{
    /// <summary>
    /// AlertServiceの単体テストクラス
    /// </summary>
    [TestClass]
    public class AlertServiceTests
    {
        private Mock<IAPPLogger> _mockAppLogger = null!;
        private Mock<IModule> _mockAlertModule = null!;
        private AlertService _target = null!;

        [TestInitialize]
        public void Setup()
        {
            Environment.SetEnvironmentVariable(EnvironmentValue.WEB_SITE_NAME, "func-test-site");
            _mockAppLogger = new Mock<IAPPLogger>();
            _mockAlertModule = new Mock<IModule>();
            SetPrivateStaticAlert(_mockAlertModule.Object);
            _target = new AlertService(_mockAppLogger.Object);
        }

        [TestCleanup]
        public void Cleanup()
        {
            SetPrivateStaticAlert(null);
        }

        private static void SetPrivateStaticAlert(IModule? module)
        {
            var field = typeof(AlertService).GetField("_alert", BindingFlags.Static | BindingFlags.NonPublic);
            field?.SetValue(null, module);
        }

        /// <summary>
        /// 正常にアラートが送信され、メッセージ内の半角波括弧が全角に置換されることを確認
        /// </summary>
        [TestMethod]
        public void Alert_正常アラート送信_波括弧全角置換()
        {
            // Arrange
            string resourceId = "res-001";
            string functionId = "func-001";
            string errorMessage = "エラーが発生しました{詳細}";

            // Act
            _target.Alert(resourceId, functionId, errorMessage);

            // Assert
            _mockAlertModule.Verify(m => m.DoSetString(
                MethodEnum.POST,
                It.Is<string>(t => t.Contains("res-001")),
                It.Is<string>(c => c.Contains("エラーが発生しました｛詳細｝"))), Times.Once);
        }

        /// <summary>
        /// モジュールが未初期化（null）の場合、例外を発生させず送信をスキップすることを確認
        /// </summary>
        [TestMethod]
        public void Alert_モジュール未初期化_送信スキップ()
        {
            // Arrange
            SetPrivateStaticAlert(null);

            // Act
            _target.Alert("res-001", "func-001", "テストメッセージ");

            // Assert
            _mockAppLogger.Verify(m => m.WriteLog(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Exception?>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Never);
        }

        /// <summary>
        /// アラート送信処理で例外が発生した場合、エラーログが出力されることを確認
        /// </summary>
        [TestMethod]
        public void Alert_送信処理例外_エラーログ出力のみ()
        {
            // Arrange
            _mockAlertModule.Setup(m => m.DoSetString(It.IsAny<MethodEnum>(), It.IsAny<string>(), It.IsAny<string>()))
                .Throws(new Exception("送信失敗"));

            // Act
            _target.Alert("res-001", "func-001", "テストメッセージ");

            // Assert
            _mockAppLogger.Verify(m => m.WriteLog(
                Messages.E_002,
                LogLevel.ERROR,
                It.IsAny<Exception?>(),
                It.IsAny<string>(),
                It.IsAny<string>(),
                It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// エラーメッセージのみ指定した場合、デフォルトの環境変数リソース名と機能IDで送信されることを確認
        /// </summary>
        [TestMethod]
        public void Alert_エラーメッセージのみ指定_デフォルトIDで送信()
        {
            // Arrange
            string errorMessage = "システム例外発生";

            // Act
            _target.Alert(errorMessage);

            // Assert
            _mockAlertModule.Verify(m => m.DoSetString(
                MethodEnum.POST,
                It.Is<string>(t => t.Contains("func-test-site")),
                It.Is<string>(c => c.Contains("システム例外発生"))), Times.Once);
        }
    }
}
