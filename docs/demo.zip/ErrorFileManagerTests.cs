﻿using Moq;
using Newtonsoft.Json;
using NotificationFunction.Models.DataLake;
using NotificationFunction.Models.Error;
using NotificationFunction.Resources;
using NotificationFunction.Service.Error;
using NotificationFunction.Service.Logger.Interfaces;

namespace NotificationFunction.Tests.Service.Error
{
    /// <summary>
    /// ErrorFileManagerの単体テストクラス
    /// </summary>
    [TestClass]
    public class ErrorFileManagerTests
    {
        private string _tempDir = null!;
        private Mock<IAlertService> _mockAlertService = null!;
        private ErrorFileManager _target = null!;

        [TestInitialize]
        public void Setup()
        {
            _tempDir = Path.Combine(Path.GetTempPath(), "ErrorFileTests_" + Guid.NewGuid());
            Environment.SetEnvironmentVariable(EnvironmentValue.ERROR_FILE_PATH, _tempDir);
            Environment.SetEnvironmentVariable(EnvironmentValue.DATALAKE_SQLDB_CONTAINER_NAMES, "sqldb-container");
            Environment.SetEnvironmentVariable(EnvironmentValue.DATALAKE_SQLMI_CONTAINER_NAMES, "sqlmi-container");
            Environment.SetEnvironmentVariable(EnvironmentValue.DATALAKE_COSMOSDBACCOUNT_CONTAINER_NAMES, "cosmosdb-container");

            _mockAlertService = new Mock<IAlertService>();
            _target = new ErrorFileManager(_mockAlertService.Object);
        }

        [TestCleanup]
        public void Cleanup()
        {
            if (Directory.Exists(_tempDir))
            {
                Directory.Delete(_tempDir, true);
            }
        }

        private static LogFileInfoModel CreateStorageModel() => new()
        {
            ContainerName = "storage-container",
            DirectoryPath = "subscriptions/sub1/resourceGroups/rg1/providers/Microsoft.Storage/storageAccounts/stacc01/blobServices/default/y=2026/m=11/d=13/h=12/m=00",
            FileName = "PT1H.json"
        };

        /// <summary>
        /// ディレクトリとファイルが未存在の場合、新規作成されることを確認
        /// </summary>
        [TestMethod]
        public async Task OutputErrorFile_ディレクトリとファイル未存在_新規作成()
        {
            // Arrange
            var model = CreateStorageModel();

            // Act
            await _target.OutputErrorFile(model, 10, false);

            // Assert
            Assert.IsTrue(Directory.Exists(_tempDir));
            var files = Directory.GetFiles(_tempDir);
            Assert.AreEqual(1, files.Length);
            var saved = JsonConvert.DeserializeObject<ErrorFile>(File.ReadAllText(files[0]))!;
            Assert.AreEqual(10, saved.Line);
            Assert.AreEqual(1, saved.ErrorCount);
            Assert.IsFalse(saved.NotificationFlag);
        }

        /// <summary>
        /// 既存ファイルが存在し連続エラー回数が閾値未満の場合、回数加算のみ行われることを確認
        /// </summary>
        [TestMethod]
        public async Task OutputErrorFile_既存ファイルあり_閾値未満_回数加算のみ()
        {
            // Arrange
            var model = CreateStorageModel();
            await _target.OutputErrorFile(model, 5, false);

            // Act
            await _target.OutputErrorFile(model, 6, true);

            // Assert
            var errorFile = await _target.GetErrorFile(model);
            Assert.AreEqual(2, errorFile.ErrorCount);
            Assert.AreEqual(6, errorFile.Line);
            Assert.IsTrue(errorFile.NotificationFlag);
            _mockAlertService.Verify(m => m.Alert(It.IsAny<string>()), Times.Never);
        }

        /// <summary>
        /// 既存ファイルが存在し連続エラー回数が規定値に達した場合、緊急アラートが発報されることを確認
        /// </summary>
        [TestMethod]
        public async Task OutputErrorFile_既存ファイルあり_閾値到達_緊急アラート発報()
        {
            // Arrange
            var model = CreateStorageModel();
            int threshold = int.Parse(AlertSettings.ALERT_ERROR_COUNT);

            // Act
            for (int i = 0; i < threshold; i++)
            {
                await _target.OutputErrorFile(model, i, false);
            }

            // Assert
            var errorFile = await _target.GetErrorFile(model);
            Assert.AreEqual(threshold, errorFile.ErrorCount);
            _mockAlertService.Verify(m => m.Alert(It.IsAny<string>()), Times.Once);
        }

        /// <summary>
        /// SQLDBログの場合、専用のファイル名形式で生成されることを確認
        /// </summary>
        [TestMethod]
        public async Task OutputErrorFile_SQLDBログ_専用ファイル名生成()
        {
            // Arrange
            var model = new LogFileInfoModel
            {
                ContainerName = "sqldb-container",
                DirectoryPath = "server01/db01/SqlDbAuditing/2026-11-13",
                FileName = "audit.xel"
            };

            // Act
            await _target.OutputErrorFile(model, 0, false);

            // Assert
            var expectedPath = Path.Combine(_tempDir, "server01_db01_audit.xel.json");
            Assert.IsTrue(File.Exists(expectedPath));
        }

        /// <summary>
        /// SQLMIログの場合、専用のファイル名形式で生成されることを確認
        /// </summary>
        [TestMethod]
        public async Task OutputErrorFile_SQLMIログ_専用ファイル名生成()
        {
            // Arrange
            var model = new LogFileInfoModel
            {
                ContainerName = "sqlmi-container",
                DirectoryPath = "subscriptions/sub1/resourceGroups/rg1/providers/Microsoft.Sql/managedInstances/sqlmi01/y=2026/m=11/d=13/h=09",
                FileName = "PT1H.json"
            };

            // Act
            await _target.OutputErrorFile(model, 0, false);

            // Assert
            var expectedPath = Path.Combine(_tempDir, "sqlmi-container_sqlmi01_09_PT1H.json.json");
            Assert.IsTrue(File.Exists(expectedPath));
        }

        /// <summary>
        /// CosmosDBログの場合、専用のファイル名形式で生成されることを確認
        /// </summary>
        [TestMethod]
        public async Task OutputErrorFile_CosmosDBログ_専用ファイル名生成()
        {
            // Arrange
            var model = new LogFileInfoModel
            {
                ContainerName = "cosmosdb-container",
                DirectoryPath = "subscriptions/sub1/resourceGroups/rg1/providers/Microsoft.DocumentDB/databaseAccounts/cosmos01/y=2026/m=11/d=13/h=15",
                FileName = "PT1H.json"
            };

            // Act
            await _target.OutputErrorFile(model, 0, false);

            // Assert
            var expectedPath = Path.Combine(_tempDir, "cosmosdb-container_cosmos01_15_PT1H.json.json");
            Assert.IsTrue(File.Exists(expectedPath));
        }

        /// <summary>
        /// エラーファイルが存在する場合、内容を正常に取得できることを確認
        /// </summary>
        [TestMethod]
        public async Task GetErrorFile_エラーファイル存在_内容取得()
        {
            // Arrange
            var model = CreateStorageModel();
            await _target.OutputErrorFile(model, 25, true);

            // Act
            var result = await _target.GetErrorFile(model);

            // Assert
            Assert.AreEqual(25, result.Line);
            Assert.IsTrue(result.NotificationFlag);
        }

        /// <summary>
        /// 削除対象ファイルが0件の場合、例外なく正常終了することを確認
        /// </summary>
        [TestMethod]
        public async Task DeleteErrorFile_対象ファイル0件_正常終了()
        {
            // Arrange
            Directory.CreateDirectory(_tempDir);
            var model = CreateStorageModel();

            // Act & Assert
            await _target.DeleteErrorFile(model);
            Assert.IsFalse(await _target.IsExists(model));
        }

        /// <summary>
        /// 削除対象ファイルが1件存在する場合、正常に削除されることを確認
        /// </summary>
        [TestMethod]
        public async Task DeleteErrorFile_対象ファイル1件_削除実行()
        {
            // Arrange
            var model = CreateStorageModel();
            await _target.OutputErrorFile(model, 1, false);
            Assert.IsTrue(await _target.IsExists(model));

            // Act
            await _target.DeleteErrorFile(model);

            // Assert
            Assert.IsFalse(await _target.IsExists(model));
        }

        /// <summary>
        /// エラーファイルが存在する場合、IsExistsがTrueを返却することを確認
        /// </summary>
        [TestMethod]
        public async Task IsExists_エラーファイルあり_True返却()
        {
            // Arrange
            var model = CreateStorageModel();
            await _target.OutputErrorFile(model, 1, false);

            // Act
            var exists = await _target.IsExists(model);

            // Assert
            Assert.IsTrue(exists);
        }

        /// <summary>
        /// エラーファイルが存在しない場合、IsExistsがFalseを返却することを確認
        /// </summary>
        [TestMethod]
        public async Task IsExists_エラーファイルなし_False返却()
        {
            // Arrange
            Directory.CreateDirectory(_tempDir);
            var model = CreateStorageModel();

            // Act
            var exists = await _target.IsExists(model);

            // Assert
            Assert.IsFalse(exists);
        }
    }
}
