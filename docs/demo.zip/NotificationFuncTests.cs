﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using NotificationFunction.Logic.Detect.Interfaces;
using NotificationFunction.Models.CosmosDB;
using NotificationFunction.Models.DataLake;
using NotificationFunction.Resources;
using NotificationFunction.Service.CosmosDB.Interfaces;
using NotificationFunction.Service.Logger.Interfaces;
using NotificationFunction.Service.Manager.Interfaces;

namespace NotificationFunction.Tests
{
    /// <summary>
    /// NotificationFuncの単体テストクラス
    /// </summary>
    [TestClass]
    public class NotificationFuncTests
    {
        private Mock<IDetectLogic> _mockDetectLogic = null!;
        private Mock<IGetDetectLog> _mockGetDetectLog = null!;
        private Mock<IDeleteDetectLog> _mockDeleteDetectLog = null!;
        private Mock<IAPPLogger> _mockAppLogger = null!;
        private Mock<IUserAccountManager> _mockUserAccountManager = null!;
        private Mock<ITimeManager> _mockTimeManager = null!;
        private Mock<ICosmosDBService> _mockCosmosService = null!;
        private ServiceProvider _serviceProvider = null!;
        private NotificationFunc _target = null!;

        [TestInitialize]
        public void Setup()
        {
            _mockDetectLogic = new Mock<IDetectLogic>();
            _mockGetDetectLog = new Mock<IGetDetectLog>();
            _mockDeleteDetectLog = new Mock<IDeleteDetectLog>();
            _mockAppLogger = new Mock<IAPPLogger>();
            _mockUserAccountManager = new Mock<IUserAccountManager>();
            _mockTimeManager = new Mock<ITimeManager>();
            _mockCosmosService = new Mock<ICosmosDBService>();

            var services = new ServiceCollection();
            services.AddScoped(_ => _mockCosmosService.Object);
            _serviceProvider = services.BuildServiceProvider();

            _target = new NotificationFunc(
                _mockDetectLogic.Object,
                _mockGetDetectLog.Object,
                _mockDeleteDetectLog.Object,
                _mockAppLogger.Object,
                _serviceProvider,
                _mockUserAccountManager.Object,
                _mockTimeManager.Object);
        }

        [TestCleanup]
        public void Cleanup()
        {
            _serviceProvider.Dispose();
        }

        /// <summary>
        /// 正常処理時、削除フラグが"1"の条件を除外して検知ロジックが実行されることを確認
        /// </summary>
        [TestMethod]
        public async Task Run_正常処理_削除フラグ除外で検知実行()
        {
            // Arrange
            _mockCosmosService.Setup(m => m.GetAllItemList<NotificationConditionsModel>())
                .ReturnsAsync([
                    new() { ConditionName = "Active", DeleteFlag = "0" },
                    new() { ConditionName = "Deleted", DeleteFlag = "1" }
                ]);
            _mockCosmosService.Setup(m => m.GetAllItemList<OperationMethodModel>())
                .ReturnsAsync([
                    new() { OperationMethod = "Read", DeleteFlag = "0" },
                    new() { OperationMethod = "Write", DeleteFlag = "1" }
                ]);
            _mockCosmosService.Setup(m => m.GetAllItemList<OperationCatalogModel>()).ReturnsAsync([]);
            _mockGetDetectLog.Setup(m => m.GetRenameLogList())
                .ReturnsAsync([new() { FileName = "1.json" }, new() { FileName = "2.json" }]);
            _mockGetDetectLog.Setup(m => m.GetXelLogList()).ReturnsAsync([]);

            // Act
            await _target.Run(new TimerInfo(), CancellationToken.None);

            // Assert
            _mockDetectLogic.Verify(m => m.RunDetectLogic(
                It.IsAny<LogFileInfoModel>(),
                It.Is<List<NotificationConditionsModel>>(c => c.Count == 1 && c[0].ConditionName == "Active"),
                It.Is<List<OperationMethodModel>>(o => o.Count == 1 && o[0].OperationMethod == "Read"),
                It.IsAny<List<OperationCatalogModel>>()), Times.Exactly(2));

            _mockUserAccountManager.Verify(m => m.RegisterDataInDB(_mockCosmosService.Object), Times.Once);
            _mockAppLogger.Verify(m => m.WriteLog(Messages.I_001, LogLevel.INFO, null, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
            _mockAppLogger.Verify(m => m.WriteLog(Messages.I_002, LogLevel.INFO, null, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// リネームログが0件の場合、検知ロジックがスキップされることを確認
        /// </summary>
        [TestMethod]
        public async Task Run_リネームログ0件_検知ロジックスキップ()
        {
            // Arrange
            _mockCosmosService.Setup(m => m.GetAllItemList<NotificationConditionsModel>()).ReturnsAsync([]);
            _mockCosmosService.Setup(m => m.GetAllItemList<OperationMethodModel>()).ReturnsAsync([]);
            _mockCosmosService.Setup(m => m.GetAllItemList<OperationCatalogModel>()).ReturnsAsync([]);
            _mockGetDetectLog.Setup(m => m.GetRenameLogList()).ReturnsAsync([]);
            _mockGetDetectLog.Setup(m => m.GetXelLogList()).ReturnsAsync([]);

            // Act
            await _target.Run(new TimerInfo(), CancellationToken.None);

            // Assert
            _mockDetectLogic.Verify(m => m.RunDetectLogic(
                It.IsAny<LogFileInfoModel>(), It.IsAny<List<NotificationConditionsModel>>(),
                It.IsAny<List<OperationMethodModel>>(), It.IsAny<List<OperationCatalogModel>>()), Times.Never);
            _mockAppLogger.Verify(m => m.WriteLog(Messages.I_002, LogLevel.INFO, null, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
        }

        /// <summary>
        /// リネームログが最大件数(100件)の場合でも並列制限内で正常に処理されることを確認
        /// </summary>
        [TestMethod]
        public async Task Run_リネームログ最大件数_並列制限内で正常終了()
        {
            // Arrange
            _mockCosmosService.Setup(m => m.GetAllItemList<NotificationConditionsModel>()).ReturnsAsync([]);
            _mockCosmosService.Setup(m => m.GetAllItemList<OperationMethodModel>()).ReturnsAsync([]);
            _mockCosmosService.Setup(m => m.GetAllItemList<OperationCatalogModel>()).ReturnsAsync([]);
            var logs = Enumerable.Range(1, 100).Select(i => new LogFileInfoModel { FileName = $"{i}.json" }).ToList();
            _mockGetDetectLog.Setup(m => m.GetRenameLogList()).ReturnsAsync(logs);
            _mockGetDetectLog.Setup(m => m.GetXelLogList()).ReturnsAsync([]);

            // Act
            await _target.Run(new TimerInfo(), CancellationToken.None);

            // Assert
            _mockDetectLogic.Verify(m => m.RunDetectLogic(
                It.IsAny<LogFileInfoModel>(), It.IsAny<List<NotificationConditionsModel>>(),
                It.IsAny<List<OperationMethodModel>>(), It.IsAny<List<OperationCatalogModel>>()), Times.Exactly(100));
        }

        /// <summary>
        /// キャンセルトークンが要求された場合、検知ロジックがスキップされることを確認
        /// </summary>
        [TestMethod]
        public async Task Run_キャンセルトークン要求あり_検知ロジックスキップ()
        {
            // Arrange
            _mockCosmosService.Setup(m => m.GetAllItemList<NotificationConditionsModel>()).ReturnsAsync([]);
            _mockCosmosService.Setup(m => m.GetAllItemList<OperationMethodModel>()).ReturnsAsync([]);
            _mockCosmosService.Setup(m => m.GetAllItemList<OperationCatalogModel>()).ReturnsAsync([]);
            _mockGetDetectLog.Setup(m => m.GetRenameLogList()).ReturnsAsync([new() { FileName = "1.json" }]);
            _mockGetDetectLog.Setup(m => m.GetXelLogList()).ReturnsAsync([]);

            using var cts = new CancellationTokenSource();
            cts.Cancel();

            // Act
            await _target.Run(new TimerInfo(), cts.Token);

            // Assert
            _mockDetectLogic.Verify(m => m.RunDetectLogic(
                It.IsAny<LogFileInfoModel>(), It.IsAny<List<NotificationConditionsModel>>(),
                It.IsAny<List<OperationMethodModel>>(), It.IsAny<List<OperationCatalogModel>>()), Times.Never);
        }

        /// <summary>
        /// 処理中に例外が発生した場合、例外をキャッチして終了ログを出さずに終了することを確認
        /// </summary>
        [TestMethod]
        public async Task Run_処理中例外発生_キャッチして正常終了()
        {
            // Arrange
            _mockGetDetectLog.Setup(m => m.Initialize()).Throws(new Exception("予期せぬエラー"));

            // Act
            await _target.Run(new TimerInfo(), CancellationToken.None);

            // Assert
            _mockAppLogger.Verify(m => m.WriteLog("Debug", LogLevel.TRACE, It.IsAny<Exception?>(),
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Once);
            _mockAppLogger.Verify(m => m.WriteLog(Messages.I_002, LogLevel.INFO, null, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()), Times.Never);
        }

        /// <summary>
        /// ヘルスチェックAPI呼び出し時に200 OK("SUCCESS")が返却されることを確認
        /// </summary>
        [TestMethod]
        public void RunHealthCheck_ヘルスチェック実行_SUCCESS返却()
        {
            // Arrange
            var req = new DefaultHttpContext().Request;

            // Act
            var result = NotificationFunc.RunHealthCheck(req) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
            Assert.AreEqual("SUCCESS", result.Value);
        }
    }
}
